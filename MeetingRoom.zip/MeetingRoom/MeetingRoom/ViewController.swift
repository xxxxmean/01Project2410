//
//  ViewController.swift
//  MeetingRoom
//
//  Created by 노민 on 2016. 9. 25..
//  Copyright © 2016년 HelloWorld. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }


}

